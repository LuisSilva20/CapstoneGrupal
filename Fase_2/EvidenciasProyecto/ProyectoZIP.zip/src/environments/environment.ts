export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCvr0lB_YFGfyMrKMf-GIrpsdaoCZIP7ns",
    authDomain: "plaformalicenciab.firebaseapp.com",
    projectId: "plaformalicenciab",
    storageBucket: "plaformalicenciab.firebasestorage.app",
    messagingSenderId: "263763295179",
    appId: "1:263763295179:web:793e6589bc619b9dd1d44e",
    measurementId: "G-H1SQKX61P8"
  }
};
